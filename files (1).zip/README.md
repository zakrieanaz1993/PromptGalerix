# PromptGalerix Landing Page

Halaman jualan sesi Bimbingan PromptGalerix. Satu fail sahaja (`index.html`), tanpa proses build.

## Muat naik ke GitHub

1. Cipta repositori baharu di GitHub (contoh: `promptgalerix-landing`).
2. Tekan **Add file > Upload files**, seret semua fail dalam folder ini (`index.html`, `.nojekyll`, `README.md`), kemudian **Commit changes**.
   - Fail `.nojekyll` bermula dengan titik. Kalau tak kelihatan dalam Finder atau Explorer, tekan Cmd+Shift+. (Mac) atau pilih "Show hidden files" (Windows).
3. Pergi ke **Settings > Pages**. Di bawah **Build and deployment**, pilih **Deploy from a branch**, cabang `main`, folder `/ (root)`, kemudian **Save**.
4. Selepas 1 hingga 2 minit, laman tersedia di `https://<nama-github>.github.io/<nama-repo>/`.

Domain sendiri: **Settings > Pages > Custom domain**, kemudian tetapkan rekod DNS mengikut arahan GitHub.

## Tetapan yang boleh diubah

Semua tetapan berada dalam `index.html`. Cari `var CONFIG=`:

| Tetapan | Fungsi |
|---|---|
| `whatsapp` | Nombor WhatsApp format antarabangsa (60137531452). Waiting list dan butiran pendaftaran dihantar ke sini. |
| `payLinks.starter` | Stripe Payment Link untuk pakej Starter. |
| `payLinks.sustain` | Stripe Payment Link Sustain (kosong kerana sold out). |
| `payLinks.scale` | Stripe Payment Link Scale bagi 2, 3 dan 6 bulan (kosong kerana sold out). |

Untuk membuka semula Sustain atau Scale, isi pautan Stripe masing-masing dan hubungi pembangun untuk membuang status sold out.

## Nota penting

- GitHub Pages percuma memerlukan repositori **awam**. Semua kandungan fail ini (nombor WhatsApp, pautan Stripe, gambar) boleh dilihat oleh sesiapa.
- Jangan sekali-kali simpan kunci rahsia Stripe (`sk_...`) dalam repositori. Hanya pautan `https://buy.stripe.com/...` yang selamat.
- Fail ini besar (lebih kurang 7.8 MB) kerana video dan gambar tertanam. Untuk page yang lebih laju, pindahkan video dan gambar ke fail berasingan.
- Halaman pendaftaran tidak menyimpan data. Butiran pendaftaran hanya sampai kepada anda melalui WhatsApp.
